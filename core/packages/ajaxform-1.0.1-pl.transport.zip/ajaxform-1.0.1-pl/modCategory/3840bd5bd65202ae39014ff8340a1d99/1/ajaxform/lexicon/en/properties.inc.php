<?php

$_lang['ajaxform_prop_form'] = 'Chunk with form for submit.';
$_lang['ajaxform_prop_snippet'] = 'Snippet, that will process specified form.';
$_lang['ajaxform_prop_frontend_css'] = 'File with css styles for frontend.';
$_lang['ajaxform_prop_frontend_js'] = 'File with javascript for frontend.';
$_lang['ajaxform_prop_actionUrl'] = 'Connector to handle ajax requests.';